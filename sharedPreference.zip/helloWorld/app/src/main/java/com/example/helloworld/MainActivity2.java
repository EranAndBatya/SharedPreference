package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView text =  (TextView)findViewById(R.id.textView2);
        SharedPreferences sp = getSharedPreferences("key", 0);
        String tValue = sp.getString("textvalue","");
        text.setText(tValue);

    }
}
